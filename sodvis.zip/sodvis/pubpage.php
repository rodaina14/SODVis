<?php include 'menuP.php';?>
<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="styles.css">
 <style >
body{

   background: #3b4835;
}
 </style>
</head>
<body>
	
	
<img src="sodvis.png"style="display: block;
  margin-left: auto;
    margin-right: auto;" >
  <li>Welcome <?php echo $_SESSION['publisher_name']; ?></li>
<li><a href="logout.php">Logout</a></li>
<h2>EXPLORE REGION</h2>
<?php include 'region.php';?>
</html>
