
<!DOCTYPE html>
<html>
<head>
  <script src="jquery-1.10.2.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato";
    transition: background-color .5s;

}
table, th, td {
  border-collapse: collapse;
    border: 1px solid white;
    margin-left: 5%;
    margin-top: 3%;
}


.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 20px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

#main {
    transition: margin-left .5s;
    padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.modal {

    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.8); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
   
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    
    width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: white;
    font-size: 35px;
    font-weight: bold;

}

.close:hover,
.close:focus {
    color: white;
    cursor: pointer;
}

</style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <br>
  <br>
  <br>
  <br>
  <a href="Mangedataset.php">MANAGE DATA SET</a><br>
<a><button onclick="document.getElementById('id01').style.display='block'" style="background:0;border:0;">MANAGE PUBLISHER</a></button>
<div id="id01" class="modal">
  <form class="modal-content animate" action="MangePublisher.php"method="POST">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
 <?php 
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("sodvis",$conn);
$query2="select* from publisher";
$result2=mysql_query($query2,$conn);
mysql_close($conn);

?>  
     

<table style=" color:white;border: 0px solid #888888; width: 70%; ";>
  <tr>
    <th></th>
    <th>publisher_name</th>
      <th>publisher_email</th>
    <th>publisher_password</th>
    <th>publisher_agency</th>
    <th>publisher_phone</th>
    
    
    
    
  
  </tr>
  <tr>
    <td></td>
    
  </tr>

<?php 

while($row=mysql_fetch_row($result2)){
print("<tr>");
     foreach ($row as  $value) 
          print("<td>$value</td>");
     print("<td><a href='dpublisherF.php?id=$row[0]'>Delete</a></td>");

print("</tr>");
}


?>
</table>
<script>
function redirect1(){
     window.location.assign("AddpublisherF.php")
}
</script><p><input  type="button" onclick="redirect1()" value="Add publisher"></p>


    </div>

  <script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
  <a href="mangestory.php">MANAGE STORY</a>
</div>

<div id="main">
  <span style="font-size:30px;color:white;cursor:pointer" onclick="openNav()">&#9776; </span>
</div>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
   
}
</script>
     
</body>


</html> 

