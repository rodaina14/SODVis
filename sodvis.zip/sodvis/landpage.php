<?php include 'AdminL.php';?>
 <!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <style >
 body{

   background: #3b4835;
}</style>
</head>
<body>
<img src="sodvis.png"style="display: block;
  margin-left: auto;
    margin-right: auto;" >
  
<h2>EXPLORE REGION</h2>
<?php include 'region.php';?>
<?php include 'footer.php';?>

</body>
</html>
