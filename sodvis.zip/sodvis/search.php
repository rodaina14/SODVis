

<?php

include "config.php";
$sql = "select * from datasets where datasets_title like '%$datasets_title%' ORDER BYid DESC";
$quary = mysql_query ($sql);

if (empty ($datasets_title)){
	echo 
<style>
	.arce {display:none;}
	.rightco {display:none;}
</style>
	
<center> <h4> Sorry, you do not search any key word </h4> </center>;
	exit ();}
	
	if (mysql_num_rows ($quary) == 0){
	echo <style>
		.arce {display:none;}
	.rightco {display:none;}
</style> 
<center> <h4> Sorry, we do not have data for this key word </h4> </center>;
exit ();
 }
 
 else{
	 echo <div class="TitleTips">
		 <h2> Topics matching your search </h2>
	 < a herf="#"> <h2 style="background: #ad272c;margin-right:-4px;" 
	 
	 </div>;
			 
		 }
		 ?>