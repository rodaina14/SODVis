<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>


/* Full-width input fields */
input[type=text], input[type=password] {
   
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    
}

/* Set a style for all buttons */
button {
    
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    background: #3b4835;
   
   
}

.container {
    padding: 16px;
}

span.psw {
    float: left;
    padding-top: 16px;

}

/* The Modal (background) */
.modal {

    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.8); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
   
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    
    width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: white;
    font-size: 35px;
    font-weight: bold;

}

.close:hover,
.close:focus {
    color: white;
    cursor: pointer;
}



/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;

    }
    .cancelbtn {
       width: 100%;
    }
}
</style>
</head>
<body>


<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;background:0;margin-left: 90%;">Login</button>

<div id="id01" class="modal">
  
  <form class="modal-content animate" action="check loginA.php"method="POST">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      
    </div>

    <div class="container" style="color: white;text-align: center;">
      <label for="admin_name"><b>USERNAME</b></label><br>
      <input type="text" placeholder="ENTER USERNAME" name="admin_name" required>
<br>
      <label for="admin_password"><b>PASSWORD</b></label><br>
      <input type="password" placeholder="ENTER PASSWORD" name="admin_password" required>
      <br>  
      <button type="submit">Login</button>
      
      
    </div>

    
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</body>
</html>

