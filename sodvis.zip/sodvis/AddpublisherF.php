<?php session_start(); ?>

<!DOCTYPE html><html>
<head>
    <head>
 <link rel="stylesheet" href="styles.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<style>

body{


   background: #3b4835;

}
input[type=text] {
    width: 70%;
    text-align: right;
    padding: 5px 5px;
    margin: 5px 0;
    display: inline-block;
    border: 1px solid #ccc;

    
}

h1,p,form{
    text-align: center;
    color: white;
    margin-top: 5%;
}
table{

    margin-left: 30%;
}
button {
    
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    background: #3b4835;
   
   
}

.container {
    padding: 16px;
}
.modal {

    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.8); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
   
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    
    width: 80%; /* Could be more or less, depending on screen size */
}
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: white;
    font-size: 35px;
    font-weight: bold;

}

.close:hover,
.close:focus {
    color: white;
    cursor: pointer;
}
</style>

<script>
function redirect(){
  window.location.assign("Adminpage.php")
} 
</script>
</head>

<body>
    
    <form method ="post" action="Addpublisher.php">


<table >
<tr><td>name</td><td><input type="text" name="publisher_name" size="50"></td></tr>
<tr><td>email</td><td><input type="text" name="publisher_email" size="50"></td></tr>
<tr><td>password</td><td><input type="text" name="publisher_password" size="50"></td></tr>
<tr><td>agency</td><td><input type="text" name="publisher_agency" size="50"></td></tr>
<tr><td>phone</td><td><input type="text" name="publisher_phone" size="50"></td></tr>

</table>

<p><input type="submit" value="Add">
<input type="button" onclick="redirect()"value="Cancel"></p>
</form></div></div>
    </div>
    </div>

</body>
    </html>