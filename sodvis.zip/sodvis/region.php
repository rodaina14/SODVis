
<div class="gallery">
  <a target="_blank" href="">
    <img src="1.png" >
  </a>
  <div class="desc">WESTREN REGION</div>
</div>

<div class="gallery">
  <a target="_blank" href="">
    <img src="2.png" >
  </a>
  <div class="desc">CENTRAL REGION</div>
</div>

<div class="gallery">
  <a target="_blank" href="">
    <img src="3.png"  >
  </a>
  <div class="desc">EASTERN PROVINCE</div>
</div>

<div class="gallery">
  <a target="_blank" href="">
    <img src="4.png"  >
  </a>
  <div class="desc">THE NORTHERN AREA</div>
</div>
<div class="gallery">
  <a target="_blank" href="">
    <img src="5.png" >
  </a>
  <div class="desc">SOUTHERN AREA</div>
</div>




<hr style="" algin="center" width="98%">
<div class="gallery">
  <a target="_blank" href="labormarket.php">
    <img src="labor.png" >
  </a>
  <div class="desc">LABOR MARKET</div>
</div>

<div class="gallery">
  <a target="_blank" href="education.php">
    <img src="education.png" >
  </a>
  <div class="desc">EDUCATION</div>
</div>

<div class="gallery">
  <a target="_blank" href="Pilgrimage.php">
    <img src="hijj.png"  >
  </a>
  <div class="desc">PILGRIMAGE</div>
</div>

<div class="gallery">
  <a target="_blank" href="industry.php">
    <img src="industry.png"  >
  </a>
  <div class="desc">INDUSTRY</div>
</div>
<div class="gallery">
  <a target="_blank" href="health.php">
    <img src="health.png" >
  </a>
  <div class="desc">HEALTH</div>
</div>
<hr style="" algin="center" width="98%">

