<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Update Datasets</title>
</head>
<body>
<?php
$conn = mysql_connect( "localhost", "root", "") or die(mysql_error());
$db = mysql_select_db( "sodvis", $conn) or die(mysql_error());

$query= "UPDATE  datasets SET datasets_title='".$_POST[ 'datasets_title' ]."',datasets_description='".$_POST[ 'datasets_description' ]."',datasets_source='".$_POST[ 'datasets_source' ]."'
,datasets_agency='".$_POST[ 'datasets_agency' ]."',datasets_Status='".$_POST[ 'datasets_Status' ]."' WHERE id=".$_POST[ 'id' ]."";
$result = mysql_query($query, $conn);

mysql_close( $conn );
header("location:Mangedataset.php");
exit();
?>
</body>
</html>
