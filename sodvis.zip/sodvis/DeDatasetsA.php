<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>

<meta charset ="utf-8">
<title>Delete datasets </title>
</head>
<body>
<?php
$conn=mysql_connect("localhost","root","")or die (mysql_error ());
$db=mysql_select_db("sodvis", $conn) or die(mysql_error());
$query= "DELETE FROM datasets WHERE id=".$_POST[ 'id' ]."";

$result = mysql_query($query , $conn);
mysql_close($conn);
header("location:Mangedataset.php");
exit();
?>
</body>
</html>