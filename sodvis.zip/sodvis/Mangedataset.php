<?php session_start(); ?>
<?php include 'menu.php';?>
 <!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="styles.css">
  <title>Manage Datasets</title>
<style >
 body{

   background: #3b4835;
}
table, th, td {
  border-collapse: collapse;
    border: 1px solid white;
    margin-left: 5%;
    margin-top: 3%;
}
.container {
    padding: 16px;
}

span.psw {
    float: left;
    padding-top: 16px;

}

.modal {

    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.8); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
   
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    
    width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: white;
    font-size: 35px;
    font-weight: bold;

}

.close:hover,
.close:focus {
    color: white;
    cursor: pointer;
}



/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;

    }
    .cancelbtn {
       width: 100%;
    }
}
</style>
</head>
<body>
<img src="sodvis.png"style="display: block;
  margin-left: auto;
    margin-right: auto;" >
<li>Welcome <?php echo $_SESSION['admin_name']; ?></li>
<li><a href="logout.php">Logout</a></li>

  
<h2>EXPLORE REGION</h2>
<div class="gallery">
  <a target="_blank" href="">
    <img src="1.png" >
  </a>
  <div class="desc">WESTREN REGION</div>
</div>

<div class="gallery">
  <a target="_blank" href="">
    <img src="2.png" >
  </a>
  <div class="desc">CENTRAL REGION</div>
</div>

<div class="gallery">
  <a target="_blank" href="">
    <img src="3.png"  >
  </a>
  <div class="desc">EASTERN PROVINCE</div>
</div>

<div class="gallery">
  <a target="_blank" href="">
    <img src="4.png"  >
  </a>
  <div class="desc">THE NORTHERN AREA</div>
</div>
<div class="gallery">
  <a target="_blank" href="">
    <img src="5.png" >
  </a>
  <div class="desc">SOUTHERN AREA</div>
</div>


<hr style="" algin="center" width="98%">

<div class="gallery">
  <a target="_blank" >
    <button onclick="document.getElementById('id02').style.display='block'" style="width:auto;background:0;">
    <img src="labor.png" ></button>
    <div class="desc">LABOR MARKET</div>
    <div id="id02" class="modal">

  </a>
  <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
    <?php 
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("sodvis",$conn);
$query2="SELECT * FROM Datasets WHERE datasets_agency='Labormarket'";
$result2=mysql_query($query2,$conn);
mysql_close($conn);

?>  
     

<table style=" color:white; width: 70%; border: 1px solid white;">
  <tr>
    <th></th>
    <th>Title</th>
      <th>Description</th>
    <th>Source</th>
    <th>Agency</th>
    <th>Date</th>
    <th>Status</th>
    
    
    
  
  </tr>
  <tr>
    <td></td>
    
  </tr>

<?php 

while($row=mysql_fetch_row($result2)){
print("<tr>");
     foreach ($row as  $value) 
          print("<td>$value</td>");
          print("<td><a href='UpdateDatasetsF.php?id=$row[0]'>Update</a></td>");
     print("<td><a href='DeDatasetsAf.php?id=$row[0]'>Delete</a></td>");
print("</tr>");
}


?>
</table>
<script>
function redirect1(){
     window.location.assign("AddDatasetsAF.php")
}
</script>
<p><input style="margin-left: 5%;"  type="button" onclick="redirect1()" value="Add Datasets"></p>


    </div>
  </div>
</div>


</div>
<script>
// Get the modal
var modal = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</div>

<div class="gallery">
  <a target="_blank">
    <button onclick="document.getElementById('id04').style.display='block'" style="width:auto;background:0;">
      <img src="education.png" >
      <div class="desc">EDUCATION</div>
    <div id="id04" class="modal">

  </a>
  <span onclick="document.getElementById('id04').style.display='none'" class="close" title="Close Modal">&times;</span>
    <?php 
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("sodvis",$conn);
$query2="SELECT * FROM Datasets WHERE datasets_agency='Education&Training'";
$result2=mysql_query($query2,$conn);
mysql_close($conn);

?>  
     

<table style=" color:white; width: 70%; border: 1px solid white;">
  <tr>
    <th></th>
    <th>Title</th>
      <th>Description</th>
    <th>Source</th>
    <th>Agency</th>
    <th>Date</th>
    <th>Status</th>
    
    
    
  
  </tr>
  <tr>
    <td></td>
    
  </tr>

<?php 

while($row=mysql_fetch_row($result2)){
print("<tr>");
     foreach ($row as  $value) 
          print("<td>$value</td>");
          print("<td><a href='UpdateDatasetsF.php?id=$row[0]'>Update</a></td>");
     print("<td><a href='DeDatasetsAf.php?id=$row[0]'>Delete</a></td>");
print("</tr>");
}


?>
</table>
<script>
function redirect1(){
     window.location.assign("AddDatasetsAF.php")
}
</script>
<p><input style="margin-left: 5%;"  type="button" onclick="redirect1()" value="Add Datasets"></p>


    </div>
  </div>
</div>


</div>
<script>
// Get the modal
var modal = document.getElementById('id04');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>


<div class="gallery">
  <a target="_blank" href="Pilgrimage.php">
    <img src="hijj.png"  >
  </a>
  <div class="desc">PILGRIMAGE</div>
</div>

<div class="gallery">
  <a target="_blank" href="industry.php">
    <img src="industry.png"  >
  </a>
  <div class="desc">INDUSTRY</div>
</div>
<div class="gallery">
  <a target="_blank" href="health.php">
    <img src="health.png" >
  </a>
  <div class="desc">HEALTH</div>
</div>
<?php include 'footer.php';?>
</body>
</html>
