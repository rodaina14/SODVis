<?php session_start(); ?>
<?php include 'menu.php';?>
<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="styles.css">
 <style >
body{

   background: #3b4835;
}
 </style>
</head>
<body>	
<li>Welcome <?php echo $_SESSION['admin_name']; ?></li>
<li><a href="logout.php">Logout</a></li>

<img src="sodvis.png"style="display: block;
  margin-left: auto;
    margin-right: auto;" >
	
<h2>EXPLORE REGION</h2>
<?php include 'region.php';?>
<?php include 'footer.php';?>

</html>
