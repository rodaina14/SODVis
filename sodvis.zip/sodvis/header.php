<html><body>

<form action="search.php" method="Get">

<input class="search" type="text" placeholder=" Search with key word ... " name="datasets_title">

<input class="sbot sbots" style="border:none; 

border-radius: 2px;
padding: 11px;
float: left;
color:#FFF;
margin-top:9px;
margin-right:4px;"

type="submit" value="serch"> 
 </form>
	 
	</body>
	<html>
	