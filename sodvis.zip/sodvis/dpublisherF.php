<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="styles.css">
<meta charset="utf-8">
<title>Delete Datasets</title>
<style type="text/css">
body{

   background: #3b4835;
}
input[type=text] {
    width: 70%;
    text-align: right;
    padding: 5px 5px;
    margin: 5px 0;
    display: inline-block;
    border: 1px solid #ccc;

    
}

h1,p,form{
	text-align: center;
	color: white;
	margin-top: 5%;
}
table{

	margin-left: 30%;
}

</style>

</style>
<script>
function redirect(){
	window.location.assign("Managedataset.php")
} 
</script>
</head>
<body>
	<div style="z-index:3" align="right">
		<div class="relative" >
<h1>Delete Datasets</h1>
<form method ="post" action="Depublisher.php">
	<?php
	$conn=mysql_connect("localhost","root","");
	$db=mysql_select_db("sodvis", $conn);
	$query="SELECT* from publisher where id=".$_GET[ 'id' ];
	$result=mysql_query($query , $conn);
	
	while ($row = mysql_fetch_assoc($result)) {
		$id=$row[ 'id' ];
		$publisher_name=$row[ 'publisher_name' ];
		$publisher_email=$row[ 'publisher_email' ];
		$publisher_password=$row[ 'publisher_password' ];
		$publisher_agency=$row[ 'publisher_agency' ];
		$publisher_phone=$row[ 'publisher_phone' ];
		
	}
	mysql_close($conn);
	?>
<table>
<tr><td> Id</td><td><input type="text" name="id" size="50" value="<?php echo $id;?>" readonly="readonly"></td></tr>
<tr><td>name</td><td><input type="text" name="publisher_name" size="50" value="<?php echo $publisher_name;?>" readonly="readonly"></td></tr>
<tr><td>email</td><td><input type="text" name="publisher_email" size="50" value="<?php echo $publisher_email;?>" readonly="readonly"></td></tr>
<tr><td>password</td><td><input type="text" name="publisher_password" size="50" value="<?php echo $publisher_password;?>" readonly="readonly"></td></tr>
<tr><td>agency</td><td><input type="text" name="publisher_agency" size="50" value="<?php echo $publisher_agency;?>" readonly="readonly"></td></tr>
<tr><td>phone</td><td><input type="text" name="publisher_phone" size="50" value="<?php echo $publisher_phone;?>" readonly="readonly"></td></tr>


<input type="hidden" name="id" size="5" value="<?php echo $id; ?>" >
</table>

<p>
	<input type="button" onclick="redirect()"value="cancel">
	<input type="submit" value="OK"onclick="myFunction()"></p>
</form></div></div>
</body>
</html>

<script>
function myFunction() {
    alert("Successfully deleted");
}
</script>

