<?php 
$username = $_POST['publisher_name'];
$password = $_POST['publisher_password'];

$username = stripcslashes($username);
$password = stripcslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

mysql_connect("localhost","root","");
mysql_select_db("sodvis");

$sql="SELECT * FROM publisher WHERE publisher_name='$username' and publisher_password='$password'";
                  $result=mysql_query($sql);
                                                    
                    $count=mysql_num_rows($result);

                         if($count==1){

								$_SESSION['publisher_name']= "publisher_name";
								$_SESSION['publisher_password']= "password";
                                        header("location:pubpage.php");
                                        }
                                        else {
												echo "error_log()";}
														ob_end_flush();
                                                      ?>


