<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="styles.css">

<meta charset="utf-8">
<title>Update Datasets</title>
<style type="text/css">
 body{

   background: #3b4835;
}

input[type=text] {
    width: 70%;
    text-align: right;
    padding: 5px 5px;
    margin: 5px 0;
    display: inline-block;
    border: 1px solid #ccc;

    
}

h1,p,form{
	text-align: center;
	color: white;
	margin-top: 5%;
}
table{

	margin-left: 30%;
}
</style>
<script>
function redirect(){
	window.location.assign("Managedataset.php")
} 
</script>
</head>
<body>
	<div style="z-index:3" align="right">
		<div class="relative" >
<h1>Update Datasets</h1>
<form method ="post" action="UpdateDatasets.php">
	<?php
	$conn=mysql_connect("localhost","root","");
	$db=mysql_select_db("sodvis", $conn);
	$query="SELECT* from datasets where id=".$_GET[ 'id' ];
	$result=mysql_query($query , $conn);
	
	while ($row = mysql_fetch_assoc($result)) {
		$id=$row[ 'id' ];
		$datasets_title=$row[ 'datasets_title' ];
		$datasets_description=$row[ 'datasets_description' ];
		$datasets_source=$row[ 'datasets_source' ];
		$datasets_agency=$row[ 'datasets_agency' ];
		$datasets_Status=$row[ 'datasets_Status' ];
	}
	mysql_close($conn);
	?>
<table>
<tr><td> id</td><td><input type="text" name="id" size="50" value="<?php echo $id;?>" ></td></tr>
<tr><td>Title</td><td><input type="text" name="datasets_title" size="50" value="<?php echo $datasets_title;?>"></td></tr>
<tr><td>Description</td><td><input type="text" name="datasets_description" size="50" value="<?php echo $datasets_description;?>" ></td></tr>
<tr><td>Source</td><td><input type="text" name="datasets_source" size="50" value="<?php echo $datasets_source;?>"></td></tr>
<tr><td>Agency</td><td><input type="text" name="datasets_agency" size="50" value="<?php echo $datasets_agency;?>"></td></tr>
<tr><td>date</td><td><input type="text" name="datasets_date" size="50" value="<?php echo $datasets_date;?>" ></td></tr>
<tr><td>Status</td><td><input type="text" name="datasets_Status" size="50" value="<?php echo $datasets_Status;?>" ></td></tr>

<input type="hidden" name="id" size="5" value="<?php echo $id; ?>" >
</table>

<p>
	<input type="button" onclick="redirect()"value="cancel">
	<input type="submit" value="OK"></p>
</form></div></div>
</body>
</html>