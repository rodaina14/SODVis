<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
<meta charset ="utf-8">
<title>Add publisher</title>
</head>
<body>
<?php 
$conn=mysql_connect("localhost","root","")or die("connt connect db </body></html>");
mysql_select_db("sodvis",$conn) or die ("not open sodvis");

$query="Insert Into publisher(publisher_name,publisher_email,publisher_password,publisher_agency,publisher_phone)
values('$_POST[publisher_name]','$_POST[publisher_email]','$_POST[publisher_password]','$_POST[publisher_agency]','$_POST[publisher_phone]')";


if (!($result=mysql_query($query,$conn))){
	print("<p>not execute query!</P>");
	die(mysql_error()."</body></html>"); }
mysql_close($conn);
header("location:Adminpage.php");
exit();
?>
</body>
</html>

