<?php 
session_start();
$username = $_POST['admin_name'];
$password = $_POST['admin_password'];

$username = stripcslashes($username);
$password = stripcslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

mysql_connect("localhost","root","");
mysql_select_db("sodvis");

$sql="SELECT * FROM admin WHERE admin_name='$username' and admin_password='$password'";
                  $result=mysql_query($sql);
                                                    
                    $count=mysql_num_rows($result);

                         if($count==1){

								$_SESSION['admin_name']= "$username";
								$_SESSION['admin_password']= "$password";
                                        header("location:Adminpage.php");
                                        }
                                      else  {
												$sql="SELECT * FROM publisher WHERE publisher_name='$username' and publisher_password='$password'";
                  $result=mysql_query($sql);
                                                    
                    $count=mysql_num_rows($result);

                         if($count==1){

								$_SESSION['publisher_name']= "$username";
								$_SESSION['publisher_password']= "$password";
                                        header("location:pubpage.php");
                                        }
                                        else {
												echo "error_log()";}
														ob_end_flush();
										 } ?>