<?php session_start(); ?>
 <?php 
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("sodvis",$conn);
$query2="select* from Datasets";
$result2=mysql_query($query2,$conn);
mysql_close($conn);

?>  
     

<table style=" color:white;border: 0px solid #888888; width: 70%; ";>
  <tr>
    <th>Title</th>
      <th>Description</th>
    <th>Source</th>
    <th>Agency</th>
    <th>Date</th>
    <th>Status</th>
  </tr>
  <tr>
    <td></td> 
  </tr>
<?php 

while($row=mysql_fetch_row($result2)){
print("<tr>");
     foreach ($row as  $value) 
          print("<td>$value</td>");
          print("<td><a href='UpdateDatasetsF.php?id=$row[0]'>Update</a></td>");
     print("<td><a href='DeDatasetsAf.php?id=$row[0]'>Delete</a></td>");
print("</tr>");
}


?>
</table>
<script>
function redirect1(){
     window.location.assign("AddDatasetsAF.php")
}
</script>