<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
    <head>
 <link rel="stylesheet" href="styles.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<style>
 body{

   background: #3b4835;
}
input[type=text] {
    width: 70%;
    text-align: right;
    padding: 5px 5px;
    margin: 5px 0;
    display: inline-block;
    border: 1px solid #ccc;

    
}

h1,p,form{
    text-align: center;
    color: white;
    margin-top: 5%;
}
table{

    margin-left: 30%;
}

.container {
    padding: 16px;
}
.modal {

    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.8); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
   
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    
    width: 80%; /* Could be more or less, depending on screen size */
}
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: white;
    font-size: 35px;
    font-weight: bold;

}

.close:hover,
.close:focus {
    color: white;
    cursor: pointer;
}
</style>

<script>
function redirect(){
  window.location.assign("Adminpage.php")
} 
</script>
</head>

<body>
    
    <form method ="post" action="AddDatasetsA.php">


<table >
<tr><td>id</td><td><input type="text" name="datasets_id" size="50"></td></tr>
<tr><td>Title</td><td><input type="text" name="datasets_title" size="50"></td></tr>
<tr><td>Description</td><td><input type="text" name="datasets_description" size="50"></td></tr>
<tr><td>Source</td><td><input type="text" name="datasets_source" size="50"></td></tr>
<tr><td>Agency</td><td>
<input list ="broweser" name="datasets_agency">
<datalist id="broweser">
<option value="Labormarket" >
<option value="Education&Training"> 
<option value="Trede"> 
<option value="Health"> 
<option value="Pilgrimage"> </datalist>
</td></tr>
<tr><td>Status</td><td><input type="text" name="datasets_Status" size="50"></td></tr>
</table>

<p><input type="submit" value="Add">
<input type="button" onclick="redirect()"value="Cancel"></p>
</form></div></div>
    </div>
    </div>

</body>
    </html>