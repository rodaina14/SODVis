 <link rel="stylesheet" href="footcss.css">

<footer class="footer-distributed">

    <div class="footer-center">
    <div>
    <img src="imgs/fa fa-map-marker.png">
    </i>
    <p><span> Kingdom of Saudi Arabia </span> Riyadh </p>
    </div>
    <div>
    <img src="imgs/fa fa-phone.png" ></i>
    <p>+199099</p>
    </div>
    <div>
    <i class="fa fa-envelope"></i>
    <p><a href="mailto:support@sodvis.com">support@sodvis.gov.sa</a></p>
    </div>
    </div>
    <div class="footer-right">
    <p class="footer-sodvis-about">
    <span>About the SODvis</span>
    SODvis provides an open, easy-to-use platform that turns data into knowledge.
    </p>
    <div class="footer-icons">
    <a href="https://ar-ar.facebook.com/saudiportal"><img src="imgs/fa fa-facebook.png" class="fa fa-facebook"></a>
    <a href="https://twitter.com/saudiegov"><img src="imgs/fa fa-twitter.png" class="fa fa-twitter"></a>
    </div>
    
    </div>
    
    <div class="footer-right">
    <center><p class="footer-sodvis-about">
    <span> Request for Publish </span>
    Send email to: Support@sodvis.gov.sa
    <br>
    - include all your information. </p>
    </div>
    <p class="copyright">Saud Open Data Visualization © 2018</p>
    </footer>