<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
<meta charset ="utf-8">
<title>Add Datasets</title>
</head>
<body>
<?php 
$conn=mysql_connect("localhost","root","")or die("connt connect db </body></html>");
mysql_select_db("sodvis",$conn) or die ("not open sodvis");

$query="Insert Into datasets(datasets_title,datasets_description,datasets_source,datasets_agency,datasets_Status)
values('$_POST[datasets_title]','$_POST[datasets_description]','$_POST[datasets_source]','$_POST[datasets_agency]','$_POST[datasets_Status]')";


if (!($result=mysql_query($query,$conn))){
	print("<p>not execute query!</P>");
	die(mysql_error()."</body></html>"); }
mysql_close($conn);
header("location:Mangedataset.php");
exit();
?>
</body>
</html>