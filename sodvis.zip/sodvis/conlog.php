<?php

$DBConnect = mysql_connect("localhost", "root", "");

if (!$DBConnect)
	die("<p>The database server is not available.</p>");

$DBSelect = mysql_select_db("sodvis", $DBConnect);

if (!$DBSelect)
	die("<p>The database is not available.</p>");

//mysql_close($DBConnect);

?>
